package udistrital.edu.co.controller;

import udistrital.edu.co.model.ProductoFresco;
import udistrital.edu.co.view.VistaEmergente;

public class Controller {
	public VistaEmergente vista;

	public Controller() {
		vista = new VistaEmergente();
		funcionar();
	}

	public void funcionar() {

		vista.mostrarInformacion("Programa para la gestion de Productos frescos y congelados.");

		String opcion = vista.pedirLeerDatos("Ingrese el producto que desea añadir: \n1.) Producto Fresco.\n2.)Producto Congelado.");
		String opcionDos = vista.pedirLeerDatos("Que tipo de producto congelado desea:\n1.)Producto congelado con aire\n2.)Producto congelado con agua\n3.)Producto congelado con nitrogeno");
		switch (opcion) {
		case "1":

			ProductoFresco fresco = new ProductoFresco();
			fresco.setFechaCaducidad(vista.pedirLeerDatos("Ingrese:\n1.)Fecha de caducidad del producto: "));
			fresco.setFechaEnvasado(vista.pedirLeerDatos("\nFecha de envasado: "));
			fresco.setNumeroLote(vista.pedirLeerDatos("\nNumero de Lote: "));
			fresco.setPaisOrigen(vista.pedirLeerDatos("\nPais de origen: "));
			vista.mostrarInformacion("Producto: " + fresco);
			
			break;
		case "2":

			switch (opcionDos) {
			case "1":
				
				break;
			case "2":
				break;
			case "3":
				
				break;
				
			default:
				vista.mostrarInformacion("Opcion no valida");
				break;
			}
			
			break;

		default:
			
			vista.mostrarInformacion("Opcion no valida");
			
			break;
		}

		
	}
}
