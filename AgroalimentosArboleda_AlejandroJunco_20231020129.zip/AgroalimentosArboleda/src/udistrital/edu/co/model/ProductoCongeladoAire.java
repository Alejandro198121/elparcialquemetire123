package udistrital.edu.co.model;

public class ProductoCongeladoAire extends ProductoCongelado {
	private double porcentageNitrogeno;
	private double porcentageOxigeno;
	private double porcentageCarbono;
	private double porcentageVaporAgua;

	public ProductoCongeladoAire(String fechaCaducidad, String numeroLote, String fechaEnvasado, String paisOrigen,
			double temperaturaMantenimiento, double porcentageNitrogeno, double porcentageOxigeno,
			double porcentageCarbono, double porcentageVaporAgua) {
		super(fechaCaducidad, numeroLote, fechaEnvasado, paisOrigen, temperaturaMantenimiento);
		this.porcentageNitrogeno = porcentageNitrogeno;
		this.porcentageOxigeno = porcentageOxigeno;
		this.porcentageCarbono = porcentageCarbono;
		this.porcentageVaporAgua = porcentageVaporAgua;
	}

	@Override
	public String toString() {
		return "ProductoCongeladoAire [porcentageNitrogeno=" + porcentageNitrogeno + ", porcentageOxigeno="
				+ porcentageOxigeno + ", porcentageCarbono=" + porcentageCarbono + ", porcentageVaporAgua="
				+ porcentageVaporAgua + ", fechaCaducidad=" + fechaCaducidad + ", numeroLote=" + numeroLote
				+ ", fechaEnvasado=" + fechaEnvasado + ", paisOrigen=" + paisOrigen + ", temperaturaMantenimiento="
				+ temperaturaMantenimiento + "]";
	}

	public double getPorcentageNitrogeno() {
		return porcentageNitrogeno;
	}

	public void setPorcentageNitrogeno(double porcentageNitrogeno) {
		this.porcentageNitrogeno = porcentageNitrogeno;
	}

	public double getPorcentageOxigeno() {
		return porcentageOxigeno;
	}

	public void setPorcentageOxigeno(double porcentageOxigeno) {
		this.porcentageOxigeno = porcentageOxigeno;
	}

	public double getPorcentageCarbono() {
		return porcentageCarbono;
	}

	public void setPorcentageCarbono(double porcentageCarbono) {
		this.porcentageCarbono = porcentageCarbono;
	}

	public double getPorcentageVaporAgua() {
		return porcentageVaporAgua;
	}

	public void setPorcentageVaporAgua(double porcentageVaporAgua) {
		this.porcentageVaporAgua = porcentageVaporAgua;
	}

}
