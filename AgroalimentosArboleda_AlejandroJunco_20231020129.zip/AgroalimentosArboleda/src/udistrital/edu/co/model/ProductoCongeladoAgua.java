package udistrital.edu.co.model;

public class ProductoCongeladoAgua extends ProductoCongelado {

	private double salinidadAgua; // en gramos de sal por litro de agua.

	public ProductoCongeladoAgua(String fechaCaducidad, String numeroLote, String fechaEnvasado, String paisOrigen,
			double temperaturaMantenimiento, double salinidadAgua) {
		super(fechaCaducidad, numeroLote, fechaEnvasado, paisOrigen, temperaturaMantenimiento);
		this.salinidadAgua = salinidadAgua;
	}

	@Override
	public String toString() {
		return "ProductoCongeladoAgua [salinidadAgua=" + salinidadAgua + ", fechaCaducidad=" + fechaCaducidad
				+ ", numeroLote=" + numeroLote + ", fechaEnvasado=" + fechaEnvasado + ", paisOrigen=" + paisOrigen
				+ ", temperaturaMantenimiento=" + temperaturaMantenimiento + "]";
	}

	public double getSalinidadAgua() {
		return salinidadAgua;
	}

	public void setSalinidadAgua(double salinidadAgua) {
		this.salinidadAgua = salinidadAgua;
	}

}
