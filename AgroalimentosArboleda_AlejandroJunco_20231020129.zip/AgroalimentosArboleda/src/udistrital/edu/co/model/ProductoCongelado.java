package udistrital.edu.co.model;

public abstract class ProductoCongelado {
	
	protected  String fechaCaducidad;
	protected String numeroLote;
	protected String fechaEnvasado;
	protected String paisOrigen;
	protected double temperaturaMantenimiento;
	
	public ProductoCongelado(String fechaCaducidad, String numeroLote, String fechaEnvasado, String paisOrigen,
			double temperaturaMantenimiento) {
		super();
		this.fechaCaducidad = fechaCaducidad;
		this.numeroLote = numeroLote;
		this.fechaEnvasado = fechaEnvasado;
		this.paisOrigen = paisOrigen;
		this.temperaturaMantenimiento = temperaturaMantenimiento;
	}

	@Override
	public String toString() {
		return "ProductoCongelado [fechaCaducidad=" + fechaCaducidad + ", numeroLote=" + numeroLote + ", fechaEnvasado="
				+ fechaEnvasado + ", paisOrigen=" + paisOrigen + ", temperaturaMantenimiento="
				+ temperaturaMantenimiento + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	public String getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(String fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public String getNumeroLote() {
		return numeroLote;
	}

	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}

	public String getFechaEnvasado() {
		return fechaEnvasado;
	}

	public void setFechaEnvasado(String fechaEnvasado) {
		this.fechaEnvasado = fechaEnvasado;
	}

	public String getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public double getTemperaturaMantenimiento() {
		return temperaturaMantenimiento;
	}

	public void setTemperaturaMantenimiento(double temperaturaMantenimiento) {
		this.temperaturaMantenimiento = temperaturaMantenimiento;
	}
	
	
}
