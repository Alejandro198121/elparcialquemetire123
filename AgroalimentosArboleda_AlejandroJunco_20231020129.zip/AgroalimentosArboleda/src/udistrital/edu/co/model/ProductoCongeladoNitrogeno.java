package udistrital.edu.co.model;

public class ProductoCongeladoNitrogeno extends ProductoCongelado {
	private String metodoCongelacion;
	private String tiempoExposicion; // en segundos

	public ProductoCongeladoNitrogeno(String fechaCaducidad, String numeroLote, String fechaEnvasado, String paisOrigen,
			double temperaturaMantenimiento, String metodoCongelacion, String tiempoExposicion) {
		super(fechaCaducidad, numeroLote, fechaEnvasado, paisOrigen, temperaturaMantenimiento);
		this.metodoCongelacion = metodoCongelacion;
		this.tiempoExposicion = tiempoExposicion;
	}

	@Override
	public String toString() {
		return "ProductoCongeladoNitrogeno [metodoCongelacion=" + metodoCongelacion + ", tiempoExposicion="
				+ tiempoExposicion + ", fechaCaducidad=" + fechaCaducidad + ", numeroLote=" + numeroLote
				+ ", fechaEnvasado=" + fechaEnvasado + ", paisOrigen=" + paisOrigen + ", temperaturaMantenimiento="
				+ temperaturaMantenimiento + "]";
	}

	public String getMetodoCongelacion() {
		return metodoCongelacion;
	}

	public void setMetodoCongelacion(String metodoCongelacion) {
		this.metodoCongelacion = metodoCongelacion;
	}

	public String getTiempoExposicion() {
		return tiempoExposicion;
	}

	public void setTiempoExposicion(String tiempoExposicion) {
		this.tiempoExposicion = tiempoExposicion;
	}

}
