package udistrital.edu.co.model;

public class ProductoFresco {
	
	private String fechaEnvasado;
	private String paisOrigen;
	private  String fechaCaducidad;
	private String numeroLote;
	
	public ProductoFresco(String fechaCaducidad, String numeroLote, String fechaEnvasado, String paisOrigen) {
		this.fechaEnvasado = fechaEnvasado;
		this.paisOrigen = paisOrigen;
	}

	public ProductoFresco() {
	}

	@Override
	public String toString() {
		return "ProductoFresco \nFecha de Envasado: " + fechaEnvasado + "\nPais de Origen: " + paisOrigen + "\nFechaCaducidad: "
				+ fechaCaducidad + "\nNumeroLote: " + numeroLote;
	}

	public String getFechaEnvasado() {
		return fechaEnvasado;
	}

	public void setFechaEnvasado(String fechaEnvasado) {
		this.fechaEnvasado = fechaEnvasado;
	}

	public String getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public String getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(String fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public String getNumeroLote() {
		return numeroLote;
	}

	public void setNumeroLote(String numeroLote) {
		this.numeroLote = numeroLote;
	}

	
	
	
	
}
