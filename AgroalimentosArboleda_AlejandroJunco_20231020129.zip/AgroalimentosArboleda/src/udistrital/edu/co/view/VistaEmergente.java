package udistrital.edu.co.view;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class VistaEmergente {
	
	Scanner leer = new Scanner(System.in);
	String vista = "";
	public VistaEmergente() {
	}
	
	public String pedirLeerDatos(String mensaje) {
		JOptionPane.showInputDialog(mensaje);
		String dato = leer.next();
		return dato;
	}
	
	public void mostrarInformacion(String mensaje) {
		JOptionPane.showMessageDialog(null, mensaje);
	}
	
}
